"use strict";
document.getElementById("ocultar").addEventListener("click", ocultarmostrar);

function ocultarmostrar(){
    document.getElementById("info").classList.toggle("oculto");
}
